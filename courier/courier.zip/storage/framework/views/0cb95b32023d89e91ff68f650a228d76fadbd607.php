
    <?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
        <div class="container-fluid">
           
           
                <table class="table table-hover table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">Date</th>
                            <th scope="col">ID</th>
                            <th scope="col">Merchant</th>
                            <th scope="col">Reciever</th>
                            <th scope="col">Status</th>
                            <th scope="col">Payment Info</th>
                            <th scope="col">Action</th>
                            
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $parcels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parcel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(@$parcel->created_at->isoFormat('Do MMM, YYYY h:m A')); ?></td>
                            <td><?php echo e(@$parcel->tracking_id); ?></td>
                            <td><?php echo e(@$parcel->merchant->name); ?>

                                <?php echo e(@$parcel->merchant->phoone); ?>

                            </td>
                            <td>
                                <p><?php echo e(@$parcel->reciever->name); ?></p>
                                <p><?php echo e(@$parcel->reciever->phone); ?></p>
                            </td>
                            <td><?php echo e(@$parcel->status); ?>

                                <form action="<?php echo e(route('admin.parcel.status', $parcel->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value=<?php echo e($parcel->id); ?>>
                                    <div class="form-group">
                                      <select class="form-control" name= "status">
                                          <option value= "1">Recieved by Parcel Goal</option>
                                          <option value= "2">Send to the nearest delivery point</option>
                                          <option value= "3">On the way to deliver</option>
                                          <option value= "4">Successfully delivered</option>
                                          <option value= "5">Customer couldn't respond</option>
                                          <option value= "6">On the way to return to mercahnt</option>
                                          <option value= "7">Successfully Returned to merchant</option>
                                      </select>
                                    </div>

                                    <button onclick="return confirm('Are you sure?')"class="text-danger">Change Status</button>
                                </form>
                            </td>
                            <td>Amount To Collect: <?php echo e(@$parcel->amount_to_collect); ?>

                               Delivery Charge: <?php echo e(@$parcel->delivery_charge); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.parcels.edit', $parcel->id)); ?>">Edit</a> 
                                <form action="<?php echo e(route('admin.parcels.destroy', $parcel->id)); ?>" method="POST">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <button onclick="return confirm('Are you sure?')" class="text-danger plain">Delete</button>
                                </form>
                                <a href="#" class="text-danger">Assign</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
  </div>
  <!-- /.content-wrapper -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/admin/pages/parcel/show.blade.php ENDPATH**/ ?>