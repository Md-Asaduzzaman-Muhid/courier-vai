
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <div class="container-fluid py-2">

                    <form method="POST" action="<?php echo e(route('merchant.update.profile.info')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('patch')); ?>

                        <h3 class="text-center mb-md-4 mb-2">personal details</h3>
                        <input type="hidden" name="merchant_id" value="<?php echo e(@$merchant->id); ?>">
                        <div class="form-group text-center mb-5">
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(@$merchant->name); ?>" required autocomplete="name" placeholder="Enter Name ..."autofocus>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group text-center mb-5">
                            <input id="phone" type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(@$merchant->phone); ?>" required autocomplete="phone" placeholder="Enter Phone Number ...">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group text-center mb-5">
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(@$merchant->email); ?>"required autocomplete="email" placeholder="Enter Email ...">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group text-center mb-5">
                            <input id="nid" type="text" class="form-control <?php $__errorArgs = ['nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nid" value="<?php echo e(@$merchant->nid); ?>" autocomplete="nid" placeholder="Enter NID Number (Optional) ...">
                            <?php $__errorArgs = ['nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group text-center mb-5">
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(@$merchant->password); ?>" name="password" autocomplete="new-password" placeholder="Enter Password ...">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                            <h3 class="text-center mb-md-4 mb-2">Company details</h3>
                            <div class="form-group text-center mb-5">
                                <input id="cName" type="text" class="form-control <?php $__errorArgs = ['cName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cName" value="<?php echo e(@$merchant->company->company_name); ?>" required autocomplete="cName" placeholder="Enter Company Name ...">
                                <?php $__errorArgs = ['cName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group text-center mb-5">
                                <input id="cUrl" type="text" class="form-control <?php $__errorArgs = ['cUrl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cUrl" value="<?php echo e(@$merchant->company->company_url); ?>" autocomplete="cUrl" placeholder="Enter Company URL(Facebook/Website) ...">

                                <?php $__errorArgs = ['cUrl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <select class="form-control <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="area" value="<?php echo e(old('area')); ?>" >
                                    <option> --- Select ---</option>
                                    <option value="Uttara"<?php echo e((isset($merchant->area) && $merchant->area == 'Uttara') ? 'selected' : ''); ?>>Uttara</option>
                                    <option value="Bashundhara R/A"<?php echo e((isset($merchant->area) && $merchant->area == 'Bashundhara R/A') ? 'selected' : ''); ?>>Bashundhara R/A</option>
                                    <option value="Gulshan"<?php echo e((isset($merchant->area) && $merchant->area == 'Gulshan') ? 'selected' : ''); ?>>Gulshan</option>
                                    <option value="Mirpur"<?php echo e((isset($merchant->area) && $merchant->area == 'Mirpur') ? 'selected' : ''); ?>>Mirpur</option>
                                    <option value="Rampura"<?php echo e((isset($merchant->area) && $merchant->area == 'Rampura') ? 'selected' : ''); ?>>Rampura</option>
                                    <option value="Badda"<?php echo e((isset($merchant->area) && $merchant->area == 'Badda') ? 'selected' : ''); ?>>Badda</option>
                                    <option value="Banani"<?php echo e((isset($merchant->area) && $merchant->area == 'Banani') ? 'selected' : ''); ?>>Banani</option>
                                    <option value="Mohammadpur"<?php echo e((isset($merchant->area) && $merchant->area == 'Mohammadpur') ? 'selected' : ''); ?>>Mohammadpur</option>
                                    <option value="Dhanmondi"<?php echo e((isset($merchant->area) && $merchant->area == 'Dhanmondi') ? 'selected' : ''); ?>>Dhanmondi</option>
                                    <option value="Old Town"<?php echo e((isset($merchant->area) && $merchant->area == 'Old Town') ? 'selected' : ''); ?>>Old Town</option>
                                    <option value="Tejgoan"<?php echo e((isset($merchant->area) && $merchant->area == 'Tejgoan') ? 'selected' : ''); ?>>Tejgoan</option>
                                    <option value="Khilgoan"<?php echo e((isset($merchant->area) && $merchant->area == 'Khilgoan') ? 'selected' : ''); ?>>Khilgoan</option>
                                    <option value="Nikunja"<?php echo e((isset($merchant->area) && $merchant->area == 'Nikunja') ? 'selected' : ''); ?>>Nikunja</option>
                                    <option value="Motijhil"<?php echo e((isset($merchant->area) && $merchant->area == 'Motijhil') ? 'selected' : ''); ?>>Motijhil</option>
                                    <option value="Demra"<?php echo e((isset($merchant->area) && $merchant->area == 'Demra') ? 'selected' : ''); ?>>Demra</option>
                                    <option value="Jatrabari" <?php echo e((isset($merchant->area) && $merchant->area == 'Jatrabari') ? 'selected' : ''); ?>>Jatrabari</option>
                                    <option value="Baridhara"<?php echo e((isset($merchant->area) && $merchant->area == 'Baridhara') ? 'selected' : ''); ?>>Baridhara</option>
                                    <option value="Shyamoli"<?php echo e((isset($merchant->area) && $merchant->area == 'Shyamoli') ? 'selected' : ''); ?>>Shyamoli</option>
                                    <option value="Mogbazar"<?php echo e((isset($merchant->area) && $merchant->area == 'Mogbazar') ? 'selected' : ''); ?>>Mogbazar</option>
                                    <option value="Bangla Motor"<?php echo e((isset($merchant->area) && $merchant->area == 'Bangla Motor') ? 'selected' : ''); ?>>Bangla Motor</option>
                                    <option value="Malibagh"<?php echo e((isset($merchant->area) && $merchant->area == 'Malibagh') ? 'selected' : ''); ?>>Malibagh</option>
                                    <option value="Elephent Road"<?php echo e((isset($merchant->area) && $merchant->area == 'Elephent Road') ? 'selected' : ''); ?>>Elephent Road</option>
                                    <option value="Green Road"<?php echo e((isset($merchant->area) && $merchant->area == 'Green Road') ? 'selected' : ''); ?>>Green Road</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <textarea name= "address" class="form-control" id="address" rows="5" ><?php echo e(@$merchant->company->address); ?></textarea>
                            </div>

                            <h3 class="text-center mb-md-4 mb-2">Payment details</h3>
                            <div class="form-group">
                                <select class="form-control <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="payment">
                                    <option> --- Select ---</option>
                                    <option value="Mobile Banking"  <?php echo e((isset($merchant->company->payment_type) && $merchant->company->payment_type == 'Mobile Banking') ? 'selected' : ''); ?>>Mobile Banking</option>
                                    <option value="Bank"  <?php echo e((isset($merchant->company->payment_type) && $merchant->company->payment_type == 'Bank') ? 'selected' : ''); ?>>Bank</option>
                                    <option value="Cash" <?php echo e((isset($merchant->company->payment_type) && $merchant->company->payment_type == 'Cash') ? 'selected' : ''); ?>>Cash</option>
                                </select>
                            </div>
                            <div class="form-group text-center mb-5">
                                <input id="accountHolder" type="text" class="form-control <?php $__errorArgs = ['accountHolder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="accountHolder" value="<?php echo e(@$merchant->company->account_holder); ?>" autocomplete="accountHolder" placeholder="Enter Account Holder Name ...">

                                <?php $__errorArgs = ['accountHolder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group text-center mb-5">
                                <input id="bankName" type="text" class="form-control <?php $__errorArgs = ['bankName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bankName" value="<?php echo e(@$merchant->company->bank_name); ?>" required autocomplete="bankName" placeholder="Enter Bank Name ...">

                                <?php $__errorArgs = ['bankName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group text-center mb-5">
                                <input id="branch" type="text" class="form-control <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="branch" value="<?php echo e(@$merchant->company->branch); ?>" autocomplete="branch" placeholder="Enter Branch Name ...">

                                <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group text-center mb-5">
                                <input id="accountNumber" type="text" class="form-control <?php $__errorArgs = ['accountNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="accountNumber" value="<?php echo e(@$merchant->company->account_number); ?>" required autocomplete="accountNumber" placeholder="Enter Account Number Name ...">

                                <?php $__errorArgs = ['accountNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <button type="submit" class="btn btn-common">Confirm Submit</button>

                </form>
        </div>
    </div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('merchant.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/merchant/pages/update_profile.blade.php ENDPATH**/ ?>