
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
        <div class="container-fluid">
          <table class="table table-hover table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Parcel ID</th>
                    <th scope="col">Date</th>
                    <th scope="col">Cash Collection</th>
                    <th scope="col">Delivery Charge</th>
                    <th scope="col">COD Charge</th>
                    <th scope="col">Total Adjustment Amount</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $parcels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parcel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e(@$parcel->tracking_id); ?></td>
                  <td><?php echo e(@$parcel->created_at->isoFormat('Do MMM, YYYY')); ?></td>
                  <td><?php echo e(@$parcel->amount_to_collect); ?></td>
                  <td><?php echo e(@$parcel->delivery_charge); ?></td>
                  <td>0</td>
                  <td><?php echo e(@$parcel->amount_to_collect - @$parcel->delivery_charge); ?></td>
                  <td>
                    <?php if(@$parcel->payment->status == 0 || @$parcel->payment->status == null): ?> Processing
                    <?php elseif(@$parcel->payment->status == 1): ?> Paid
                    <?php elseif(@$parcel->payment->status == 2): ?> Something wrong
                    <?php else: ?> Unknown
                    <?php endif; ?>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('merchant.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/merchant/pages/payment/show.blade.php ENDPATH**/ ?>