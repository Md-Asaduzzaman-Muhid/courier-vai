

<?php $__env->startSection('content'); ?>
<section class="py-5">
    <div class="container ">
        <p class="text-danger text-center">you searched for <b><?php echo e($id); ?></b> is not available</p>
    </div>
    <form class="tracking-form" method="GET" action="<?php echo e(route('parcel.track')); ?>"role="search">
        <h2 class="text-white">Track Your Parcel</h2>
        <div class="input-group">
            <input type="text" name="tracking_id" class="form-control" placeholder="Enter Your Tracking No ..."
                   aria-label="tracking_id" aria-describedby="tracking_id">
            <div class="input-group-append">
                <button class="btn btn-solid text-uppercase" type="submit">Track</button>
            </div>
        </div>
    </form>
</section>
<section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/anonymous/track_again.blade.php ENDPATH**/ ?>