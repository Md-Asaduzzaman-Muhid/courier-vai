
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <div class="container-fluid">
        <form action=" <?php echo e(route('merchant.pickup.store')); ?>" method="post" class="form">
           <?php echo csrf_field(); ?>
           <div class="row">
               <div class="col-md-5">
                    <div class="form-group">
                        <input name="total_parcel" type="text" class="form-control" placeholder="Number of parcel">
                    </div>
                </div>
                <div class="col-md-5">
                   <div class="form-group">
                       <input type="datetime-local" name="pickup_time" class="form-control" placeholder="Preferable Time to pickup">
                   </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-common">Confirm Submit</button>
                </div>
           </div>

       </form>
      </div>
        <div class="container-fluid">
            <table class="table table-hover table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Time Request</th>
                        <th scope="col">Time Collect</th>
                        <th scope="col">Number of Parcel</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pickups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pickup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(@$pickup->created_at); ?></td>
                    <td><?php echo e(@$pickup->pickup_time); ?></td>
                    <td><?php echo e(@$pickup->total_parcel); ?></td>
                    <td><?php if($pickup->status == 0 || $pickup->status == null): ?> Submited 
                        <?php elseif($pickup->status == 1): ?> Request Accepted 
                        <?php elseif($pickup->status == 2): ?> Pickup Done 
                        <?php else: ?> Unknown 
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('merchant.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/merchant/pages/pickup/show.blade.php ENDPATH**/ ?>