<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Parcel Goal</title>
    <link rel="icon" href="<?php echo e(asset('img/common/favicon.png')); ?>" sizes="32x32" type="image/png">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(url('css/fontawesome/all.min.css')); ?>">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href=" <?php echo e(url('css/overlayscrol/OverlayScrollbars.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/summernote-bs4.min.css')); ?>">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    </head>

    <body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
        <div class="wrapper">
        
            <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
            <?php echo $__env->yieldContent('content'); ?>
            
            <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->
    <!-- jQuery -->
    <script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- overlayScrollbars -->
    <script src="<?php echo e(url('js/OverlayScrollbars.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(url('js/adminlte.js')); ?>"></script>

    <!-- OPTIONAL SCRIPTS -->
    <!-- <script src="dist/js/demo.js"></script> -->

    <!-- PAGE PLUGINS -->
    <!-- jQuery Mapael -->
    <script src="<?php echo e(url('js/jquery.mousewheel.js')); ?>"></script>
    <script src="<?php echo e(url('js/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/jquery.mapael.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/usa_states.min.js')); ?>"></script>
    <!-- ChartJS -->
    <script src="<?php echo e(url('js/Chart.min.js')); ?>"></script>

    <!-- PAGE SCRIPTS -->
    <script src="<?php echo e(url('js/dashboard2.js')); ?>"></script>
    <script src="<?php echo e(url('js/summernote-bs4.min.js')); ?>"></script>
    <script>
        $(function () {
            // Summernote
            $('.textarea').summernote()
        })
    </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>