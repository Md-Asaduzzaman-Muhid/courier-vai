
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <div class="container-fluid">
            <table class="table table-hover table-bordered">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">Merchant Name</th>
                    <th scope="col">Time Request</th>
                    <th scope="col">Time To Collect</th>
                    <th scope="col">Number of Parcel</th>
                    <th scope="col">Status</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pickups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pickup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(@$pickup->merchant->name); ?></td>
                        <td><?php echo e(@$pickup->created_at); ?></td>
                        <td><?php echo e(@$pickup->pickup_time); ?></td>
                        <td><?php echo e(@$pickup->total_parcel); ?></td>

                        <td><?php if($pickup->status == 0 || $pickup->status == null): ?> Submited
                            <?php elseif($pickup->status == 1): ?> Request Accepted
                            <?php elseif($pickup->status == 2): ?> Pickup Done
                            <?php else: ?> Unknown
                            <?php endif; ?>
                            <form action="<?php echo e(route('admin.pickup.update', $pickup->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <input type="hidden" name="id" value=<?php echo e($pickup->id); ?>>
                                <div class="form-group">
                                    <select class="form-control" name= "status">
                                        <option value= "1">Request Accepted</option>
                                        <option value= "2">Pickup Done</option>
                                    </select>
                                </div>
                                <button onclick="return confirm('Are you sure?')" class="text-danger">Change Status</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/admin/pages/pickup/show.blade.php ENDPATH**/ ?>