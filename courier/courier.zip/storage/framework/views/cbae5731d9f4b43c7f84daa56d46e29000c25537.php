
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <div class="container-fluid py-5">
            <table class="table table-hover table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">ID</th>
                        <th scope="col">Merchant</th>
                        <th scope="col">Reciever</th>
                        <th scope="col">Status</th>
                        <th scope="col">Payment Info</th>
                        <th scope="col">Action</th>
                        
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $parcels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parcel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(@$parcel->created_at->isoFormat('Do MMM, YYYY h:m A')); ?></td>
                        <td><?php echo e(@$parcel->tracking_id); ?></td>
                        <td><?php echo e(@$merchant_name); ?></td>
                        <td><p class="mb-0"><?php echo e(@$parcel->reciever->name); ?></p>
                            <p class="mb-0"><?php echo e(@$parcel->reciever->phone); ?></p>
                            <p class="mb-0"><?php echo e(@$parcel->reciever->address); ?></p>
                        </td>
                        <td>
                            <?php if($parcel->status == 0 || $parcel->status == null): ?> Parcel Created
                            <?php elseif($parcel->status == 1): ?> Recieved by parcel goal
                            <?php elseif($parcel->status == 2): ?> Send to nearest delivery point
                            <?php elseif($parcel->status == 3): ?> On the way to deliver
                            <?php elseif($parcel->status == 4): ?> Successfully delivered
                            <?php elseif($parcel->status == 5): ?> Customer didn't respond
                            <?php elseif($parcel->status == 6): ?> On the way to return
                            <?php elseif($parcel->status == 7): ?> Returned to merchant
                            <?php else: ?> Unknown Status
                            <?php endif; ?>
                    
                        </td>
                        <td><p class="mb-0">Amount To Collect : <?php echo e(@$parcel->amount_to_collect); ?></p>
                            <p class="mb-0">Delivery Charge : <?php echo e(@$parcel->delivery_charge); ?></p>
                        </td>
                        <td><a href="<?php echo e(route('merchant.parcels.edit', $parcel->id)); ?>">Edit</a> 

                        <form action="<?php echo e(route('merchant.parcels.destroy', $parcel->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button onclick="return confirm('Are you sure?')" class="text-danger">Delete</button>
                        </form>
                        <a href="#" class="text-danger">Raise Issue</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>  
    </div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('merchant.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/merchant/pages/parcel/show.blade.php ENDPATH**/ ?>