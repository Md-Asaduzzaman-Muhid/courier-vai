

<?php $__env->startSection('content'); ?>
    <section class="career py-4">
        <div class="container">
            <h2 class="page-title text-center">About Us</h2>
            <p>Parcel Goal</p>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\courier-vai\courier\resources\views/anonymous/about.blade.php ENDPATH**/ ?>