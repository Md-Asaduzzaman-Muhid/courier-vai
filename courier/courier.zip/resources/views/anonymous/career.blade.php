@extends('layouts.app')

@section('content')
    <section class="career py-4">
        <div class="container">
            <h2 class="page-title text-center">Career</h2>
            <p>No Job Opening</p>
        </div>
    </section>
@endsection
