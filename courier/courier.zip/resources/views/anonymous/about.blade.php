@extends('layouts.app')

@section('content')
    <section class="career py-4">
        <div class="container">
            <h2 class="page-title text-center">About Us</h2>
            <p>Parcel Goal</p>
        </div>
    </section>
@endsection
